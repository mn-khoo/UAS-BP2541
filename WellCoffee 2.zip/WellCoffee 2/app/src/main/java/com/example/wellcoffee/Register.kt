package com.example.wellcoffee

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView

class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)

        val img_back : ImageView = findViewById(R.id.img_back)
        val edt_email : EditText = findViewById(R.id.edt_email)
        val edt_username : EditText = findViewById(R.id.edt_username)
        val edt_password : EditText = findViewById(R.id.edt_password)
        val btn_signup : Button = findViewById(R.id.btn_signup)

        img_back.setOnClickListener{
            val pindah: Intent = Intent(this, Login::class.java)
            startActivity(pindah)
        }

        btn_signup.setOnClickListener {
            val isi_email: String = edt_email.text.toString()
            val isi_username: String = edt_username.text.toString()
            val isi_password: String = edt_password.text.toString()
            val isi_level : String = "2"


            val dbwell: SQLiteDatabase = openOrCreateDatabase("wellcoffee", MODE_PRIVATE,null)
            val sql = "INSERT INTO user (email,nama,password,level) VALUES (?,?,?,?)"

            val statement = dbwell.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1,isi_email)
            statement.bindString(2,isi_username)
            statement.bindString(3,isi_password)
            statement.bindString(4,isi_level)
            statement.executeInsert()

            val pindah:Intent=Intent(this, Login::class.java)
            startActivity(pindah)
        }
    }
}