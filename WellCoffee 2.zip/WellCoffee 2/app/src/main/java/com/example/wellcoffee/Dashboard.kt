package com.example.wellcoffee

import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream
import java.lang.Exception

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard)


        //btn logout
        val crd_menu: CardView = findViewById(R.id.crd_menu)
        val crd_reservasi: CardView = findViewById(R.id.crd_reservasi)
        val crd_logout:CardView = findViewById(R.id.crd_logout)

        val tiket: SharedPreferences = getSharedPreferences("user", MODE_PRIVATE)
        crd_menu.setOnClickListener {
            val pindah: Intent = Intent(this,Menu::class.java)
            startActivity(pindah)
        }

        crd_reservasi.setOnClickListener {

            val pindah: Intent = Intent(this,Reservasi::class.java)
            startActivity(pindah)
        }

        crd_logout.setOnClickListener {
            val edittiket = tiket.edit()
            edittiket.clear()
            edittiket.commit()

            val keluar: Intent = Intent(this,Login::class.java)
            startActivity(keluar)
            finish()
        }


    }
}