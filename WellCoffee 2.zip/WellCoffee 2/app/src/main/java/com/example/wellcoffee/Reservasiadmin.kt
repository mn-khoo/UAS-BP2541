package com.example.wellcoffee

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class Reservasiadmin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.reservasiadmin)

        val img_back : ImageView = findViewById(R.id.img_back)
        img_back.setOnClickListener{
            val pindah: Intent = Intent(this, Dash_admin::class.java)
            startActivity(pindah)
        }
    }
}