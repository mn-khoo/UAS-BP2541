package com.example.wellcoffee

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.cardview.widget.CardView

class Dash_admin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dash_admin)

        val crd_reservasi: CardView = findViewById(R.id.crd_reservasi)
        val crd_logout: CardView = findViewById(R.id.crd_logout)
        val tiket: SharedPreferences = getSharedPreferences("user", MODE_PRIVATE)

        crd_reservasi.setOnClickListener {

            val pindah: Intent = Intent(this,Reservasiadmin::class.java)
            startActivity(pindah)
        }

        crd_logout.setOnClickListener {
            val edittiket = tiket.edit()
            edittiket.clear()
            edittiket.commit()

            val keluar: Intent = Intent(this,Login::class.java)
            startActivity(keluar)
            finish()
        }

    }
}