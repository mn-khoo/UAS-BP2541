package com.example.wellcoffee

import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        val edt_email : EditText = findViewById(R.id.edt_email)
        val edt_password : EditText = findViewById(R.id.edt_password)
        val btn_signin : Button = findViewById(R.id.btn_signin)
        val btn_signup : Button = findViewById(R.id.btn_signup)

        btn_signin.setOnClickListener {
            val isi_email: String = edt_email.text.toString()
            val isi_password: String = edt_password.text.toString()

            val dbkampus: SQLiteDatabase = openOrCreateDatabase("wellcoffee", MODE_PRIVATE, null)
            val query = dbkampus.rawQuery("SELECT * FROM user WHERE email ='$isi_email' AND password ='$isi_password'",null)
            val cek = query.moveToNext()

            if (cek) {
                val id_pelogin = query.getString(0)
                val nama_pelogin = query.getString(1)
                val email_pelogin = query.getString(2)
                val password_pelogin = query.getString(3)
                val level_pelogin = query.getString(4)

                val session: SharedPreferences = getSharedPreferences("user", MODE_PRIVATE)
                val buattiket = session.edit()

                buattiket.putString("id_user", id_pelogin)
                buattiket.putString("nama_user", nama_pelogin)
                buattiket.putString("email_user", email_pelogin)
                buattiket.putString("password_user", password_pelogin)
                buattiket.putString("level", level_pelogin)
                buattiket.commit()

                if (level_pelogin=="2") {
                    val pindah: Intent = Intent(this, Dashboard::class.java)
                    startActivity(pindah)
                }
                if(level_pelogin=="1"){
                    val pindah: Intent = Intent(this, Dash_admin::class.java)
                    startActivity(pindah)
                }
            }else{
                Toast.makeText(this,"Email atau password salah!", Toast.LENGTH_LONG).show()
            }
        }
        btn_signup.setOnClickListener {

            val pindah: Intent = Intent(this, Register::class.java)
            startActivity(pindah)
        }
    }
}