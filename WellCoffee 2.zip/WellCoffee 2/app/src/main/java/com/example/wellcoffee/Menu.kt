package com.example.wellcoffee

import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.FragmentContainerView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayInputStream
import java.lang.Exception

class Menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu)

        val btn_coffee: ImageView =findViewById(R.id.btn_coffee)
        val btn_freshdrink: ImageView =findViewById(R.id.btn_freshdrink)
        val btn_food: ImageView =findViewById(R.id.btn_food)
        val rv_menu : RecyclerView = findViewById(R.id.rv_menu)

        val btn_kembali:ImageView = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val kembali:Intent=Intent(this,Dashboard::class.java)
            startActivity(kembali)
        }

        val id : MutableList<String> = mutableListOf()
        val nama:MutableList<String> = mutableListOf()
        val harga:MutableList<String> = mutableListOf()
        val foto:MutableList<Bitmap> = mutableListOf()

        val dbcoffee:SQLiteDatabase = openOrCreateDatabase( "wellcoffee", MODE_PRIVATE, null)
        val gali = dbcoffee.rawQuery("SELECT * FROM coffee", null)
        while (gali.moveToNext())
        {
            try {
                val bis = ByteArrayInputStream(gali.getBlob(3))
                val gambarbitmap:Bitmap = BitmapFactory.decodeStream(bis)
                foto.add(gambarbitmap)
            }catch (e:Exception){
                val gambarbitmap:Bitmap = BitmapFactory.decodeResource(this.resources, R.drawable.noimage)
                foto.add(gambarbitmap)
            }


            id.add(gali.getString(0))
            nama.add(gali.getString(1))
            harga.add(gali.getString(2))
        }
        val mi = Dashboard_item(this, id,nama, harga, foto)

        rv_menu.adapter = mi
        rv_menu.layoutManager = GridLayoutManager(this, 2)

        val btn_tambah:Button = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener(){
            val pindah:Intent= Intent(this, Menu_tambah::class.java)
            startActivity(pindah)
        }
    }
}