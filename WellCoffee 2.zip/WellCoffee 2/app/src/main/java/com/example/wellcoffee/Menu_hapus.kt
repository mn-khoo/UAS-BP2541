package com.example.wellcoffee

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Menu_hapus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu_hapus)

        val id_dash_terpilih:String = intent.getStringExtra("id_mahasiswa_terpilih").toString()
        val dbkampus: SQLiteDatabase = openOrCreateDatabase( "wellcoffee", MODE_PRIVATE, null)
        val query = dbkampus.rawQuery("DELETE FROM coffee WHERE id='$id_dash_terpilih'", null)
        query.moveToNext()

        val pindah:Intent=Intent(this,Menuadmin::class.java)
        startActivity(pindah)
    }
}