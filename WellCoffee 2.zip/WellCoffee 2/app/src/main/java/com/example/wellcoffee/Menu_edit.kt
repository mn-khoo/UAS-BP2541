package com.example.wellcoffee

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import java.io.ByteArrayInputStream
import java.lang.Exception

class Menu_edit : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var iv_upload : ImageView? = null
        setContentView(R.layout.menu_edit)
        val id_dashboard_terpilih:String = intent.getStringExtra("id_dashboard_terpilih").toString()

        val dbwellcoffe: SQLiteDatabase = openOrCreateDatabase("wellcoffee", MODE_PRIVATE, null)
        val ambil = dbwellcoffe.rawQuery("SELECT * FROM Dasahboard WHERE id_menu = '$id_dashboard_terpilih'",null)
        val dshterpilih = ambil.moveToNext()

        val isi_nama:String = ambil.getString(1)
        val isi_harga:String = ambil.getString(2)
        val isi_foto:ByteArray = ambil.getBlob(3)

        val edt_nama: EditText =findViewById(R.id.edt_namaproduk)
        val edt_harga: EditText =findViewById(R.id.edt_harga)
        val btn_simpan: Button =findViewById(R.id.btn_simpan)

        iv_upload = findViewById(R.id.iv_upload)

        edt_nama.setText(isi_nama)
        edt_harga.setText(isi_harga)

        try {
            val bis = ByteArrayInputStream(isi_foto)
            val gambarbitmap: Bitmap = BitmapFactory.decodeStream(bis)
            iv_upload.setImageBitmap(gambarbitmap)
        }catch (e: Exception){
            val gambarbitmap: Bitmap = BitmapFactory.decodeResource(this.resources, R.drawable.noimage)
            iv_upload.setImageBitmap(gambarbitmap)
        }

        btn_simpan.setOnClickListener {
            val nama_baru:String = edt_nama.text.toString()
            val harga_baru:String = edt_harga.text.toString()

            val ubah = dbwellcoffe.rawQuery("UPDATE mahasiswa SET nama='$nama_baru',harga='$harga_baru' WHERE id='$id_dashboard_terpilih'",null)
            ubah.moveToNext()

            val pindah: Intent = Intent(this,Dash_admin::class.java)
            startActivity(pindah)
        }
    }
}