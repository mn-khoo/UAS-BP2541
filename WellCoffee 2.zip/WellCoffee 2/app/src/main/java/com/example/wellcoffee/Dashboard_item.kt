package com.example.wellcoffee

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.wellcoffee.R

class Dashboard_item (val ini :Context, val id: MutableList<String>, val nama: MutableList<String>, val harga:MutableList<String>, val foto:MutableList<Bitmap>) : RecyclerView.Adapter<Dashboard_item.ViewHolder>(){
    //dapatkan dulu layoutnya mahasiswa_item
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.dashboard_item, parent, false)
        return ViewHolder(view)
    }
    class ViewHolder (ItemView:View) : RecyclerView.ViewHolder(ItemView){
        val txt_nama:TextView = itemView.findViewById(R.id.txt_nama)
        val txt_harga:TextView = itemView.findViewById(R.id.txt_harga)
        val iv_foto:ImageView = itemView.findViewById(R.id.iv_gambar)
        val btn_hapus:Button = itemView.findViewById(R.id.btn_hapus)
        val btn_ubah:Button = itemView.findViewById(R.id.btn_edit)
    }

    override fun getItemCount(): Int {
        return nama.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txt_nama.text = nama.get(position)
        holder.txt_harga.text = harga.get(position)
        holder.iv_foto.setImageBitmap(foto.get(position))

        //btn hapus ditekan
        holder.btn_hapus.setOnClickListener {
            //dapatkan id_mahasiswa sesuai urutan dari tempat yang di tekan
            val id_mahasiswa_terpilih:String = id.get(position)
            //larikan ke activity mahasiswa_hapus
            val pindah:Intent = Intent(ini,Menu_hapus::class.java)
            pindah.putExtra("id_mahasiswa_terpilih", id_mahasiswa_terpilih)
            ini.startActivity(pindah)
        }
        holder.btn_ubah.setOnClickListener {
            val id_mahasiswa_terpilih:String = id.get(position)
            //larikan ke activity mahasiswa_hapus
            val pindah:Intent = Intent(ini,Menu_edit::class.java)
            pindah.putExtra("id_mahasiswa_terpilih", id_mahasiswa_terpilih)
            ini.startActivity(pindah)
        }
    }
}