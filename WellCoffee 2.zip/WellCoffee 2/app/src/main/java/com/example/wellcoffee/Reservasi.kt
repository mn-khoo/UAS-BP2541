package com.example.wellcoffee

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast

class Reservasi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.reservasi)

        val img_back : ImageView = findViewById(R.id.img_back)
        val edt_email : EditText = findViewById(R.id.edt_email)
        val edt_nama : EditText = findViewById(R.id.edt_nama)
        val edt_tgl : EditText = findViewById(R.id.edt_tgl)
        val edt_jumlahorang : EditText = findViewById(R.id.edt_jumlahorang)
        val edt_kegiatan : EditText = findViewById(R.id.edt_kegiatan)
        val btn_kirim : Button = findViewById(R.id.btn_kirim)

        img_back.setOnClickListener{
            val pindah: Intent = Intent(this, Dashboard::class.java)
            startActivity(pindah)
        }
        btn_kirim.setOnClickListener {
            val isi_email: String = edt_email.text.toString()
            val isi_nama: String = edt_nama.text.toString()
            val isi_tgl: String = edt_tgl.text.toString()
            val isi_jumlahorang: String = edt_jumlahorang.text.toString()
            val isi_kegiatan: String = edt_kegiatan.text.toString()


            val dbwell: SQLiteDatabase = openOrCreateDatabase("wellcoffee", MODE_PRIVATE,null)
            val sql = "INSERT INTO reservasi (email,nama,tanggal,jumlahorang,kegiatan) VALUES (?,?,?,?,?)"

            val statement = dbwell.compileStatement(sql)
            statement.clearBindings()
            statement.bindString(1,isi_email)
            statement.bindString(2,isi_nama)
            statement.bindString(3,isi_tgl)
            statement.bindString(4,isi_jumlahorang)
            statement.bindString(5,isi_kegiatan)
            statement.executeInsert()

            val pindah:Intent=Intent(this, Dashboard::class.java)
            Toast.makeText(this,"Reservasi terkirim, cek email anda untuk informasi selanjutnya", Toast.LENGTH_LONG).show()
            startActivity(pindah)
            }

    }
}